package PackageUsers;

public class NotSeniorTech extends Technician{

	public NotSeniorTech() {
		// TODO Auto-generated constructor stub
	}
}
